import streamlit as st
import pandas as pd 
import pymysql
import time
import matplotlib.pyplot as plt


connection =pymysql.connect(
    host="localhost",
    user="root",
    password="praveenK98@",
    database="SPORTSAPI_RADAR_DATA"
)

mycursor=connection.cursor()
st.image("C:/Users/user/Downloads/Tennisimage.jpg", width=100)




st.title("TENNIS SPORT RADAR")
st.write("\n")
#st.image("C:/Users/user/Downloads/Tennisimage.jpg",width=150)
with st.sidebar:
    # Center an image in the sidebar"
    #"This image is centered in the sidebar"
    st.image("C:/Users/user/Downloads/Tennisimage.jpg")

#"Behavior of other images stays unaltered"

st.subheader("COMPETITOR TABLE")
mycursor.execute("select * from Competitors ")
columns = [desc[0] for desc in mycursor.description]
data=mycursor.fetchall()
df = pd.DataFrame(data, columns=columns)
r=st.sidebar.radio('navigaion',['Home','about us'])
if r=='Home':
    col=st.sidebar.selectbox("select a column",df.columns)
    st.write("Home Page")
else:
  st.success("You are here")
st.balloons()

mycursor.execute("""SELECT Competitors.name,Competitor_Rankings1.Ranks,Competitor_Rankings1.points
                FROM Competitors inner join Competitor_Rankings1 ON 
                 Competitors.competitor_id=Competitor_Rankings1.competitor_id""")
D1=mycursor.fetchall()
columns_2 = ["name", "Ranks", "points"]
A1=pd.DataFrame(D1,columns=columns_2)
st.write(A1)
#st.write("Columns in DataFrame:", df.columns)  for checking the columns names

plt.style.use("ggplot")
fig, ax = plt.subplots()
ax.plot(df['competitor_id'],df['name'],df['country'],df['country_code'],df['abbreviation'])
st.pyplot(fig)
st.line_chart(df['name'])


#Graph

data1=df["competitor_id"].count()
st.sidebar.metric(label="TOTAL NO OF COMPETITOR",value=data1)
data2=df["country"].nunique()
st.sidebar.metric(label="TOTAL COUNTRY",value=data2)



mycursor.execute("""select name, max(points) from(SELECT Competitors.name,Competitor_Rankings1.Ranks,Competitor_Rankings1.points
                FROM Competitors inner join Competitor_Rankings1 ON 
                 Competitors.competitor_id=Competitor_Rankings1.competitor_id) as JOINT_TABLE GROUP BY 
    name
LIMIT 0, 1000;""")
D1=mycursor.fetchall()
columns_3=["name", "points"]
A1=pd.DataFrame(D1,columns=columns_3)

cl=st.sidebar.dataframe(A1,hide_index=True)


#Graph

mycursor.execute("""select Competitors.competitor_id, Competitors.name,Competitors.country,
                 Competitors.country_code,Competitors.abbreviation
                  ,Competitor_Rankings1.ranks,Competitor_Rankings1.points from Competitors inner 
                 join Competitor_Rankings1 on Competitors.competitor_id=Competitor_Rankings1.competitor_id """)

C1=mycursor.fetchall()
columns_4=['competitor_id','name','country','country_code','abbreviation','ranks','points']
C2=pd.DataFrame(C1,columns=columns_4)
st.dataframe(C2,hide_index=True)

search_name = st.text_input("Search for a competitor by name:")
if search_name:
    filtered_df = C2[C2['name'].str.contains(search_name, case=False, na=False)]
else:
    filtered_df = C2

#st.write("DataFrame Columns:", C2.columns)
#st.write("DataFrame Preview:", C2.head())
fig, ax = plt.subplots()
try:
    ax.plot(C2['competitor_id'], C2['name'], C2['country'], C2['country_code'],
            C2['abbreviation'],C2['ranks'],  C2['points'])
    ax.set_xlabel('Competitor ID')
    ax.set_ylabel('ranks')
    ax.set_title('Competitor Data Overview')
    st.line_chart(C2['ranks'])
    st.pyplot(fig)
except KeyError as e:
    st.error(f"KeyError: {e}")
    st.write("Available columns in DataFrame:", C2.columns)


st.dataframe(filtered_df, hide_index=True)
min_rank, max_rank = st.sidebar.slider("Select rank range", 1, 1000, (1, 100))

filtered_df = C2[(C2['ranks'] >= min_rank) & (C2['ranks'] <= max_rank)]

st.subheader("FILTER TABLE BY RANK")
# Display the filtered DataFrame
st.dataframe(filtered_df, hide_index=True)

country = st.selectbox("Select country", C2['country'].unique())
filtered_df = C2[C2['country'] == country]

st.dataframe(filtered_df)

mycursor.execute("""SELECT country,sum(points) as Total_points from (select Competitors.competitor_id, Competitors.name,Competitors.country,
                 Competitors.country_code,Competitors.abbreviation
                  ,Competitor_Rankings1.ranks,Competitor_Rankings1.points from Competitors inner 
                 join Competitor_Rankings1 on Competitors.competitor_id=Competitor_Rankings1.competitor_id) as jointable group by country 
                 ORDER BY Total_points DESC LIMIT 3""")

joined_tab = mycursor.fetchall()
columns_5=['country','total points']
df4 = pd.DataFrame(joined_tab,columns=columns_5)
st.sidebar.write("TOP THREE COUNTRIES")
st.sidebar.dataframe(df4, hide_index=True)
fig, ax = plt.subplots()
try:
    ax.plot(df4['country'], df4['total points'])
    ax.set_xlabel('country')
    ax.set_ylabel('total points')
    ax.set_title('TOP THREE COUNTRIES')
    st.line_chart(df4['total points'])
    st.pyplot(fig)
except KeyError as e:
    st.error(f"KeyError: {e}")
    st.write("Available columns in DataFrame:", df4.columns)


st.header("Leaderboards")

mycursor.execute("""
    SELECT Competitors.name, Competitors.country, Competitor_Rankings1.ranks, Competitor_Rankings1.points
    FROM Competitors
    INNER JOIN Competitor_Rankings1 ON Competitors.competitor_id = Competitor_Rankings1.competitor_id
    ORDER BY Competitor_Rankings1.ranks ASC
    LIMIT 10
""")

top_ranked = mycursor.fetchall()
top_ranked_df = pd.DataFrame(top_ranked, columns=["Name", "Country", "Rank", "Points"])
st.subheader("Top-Ranked Competitors")
st.dataframe(top_ranked_df, hide_index=True)

fig, ax = plt.subplots()
try:
    ax.plot(top_ranked_df['Name'], top_ranked_df['Country'], top_ranked_df['Rank'], top_ranked_df['Points'])
    ax.set_xlabel('Name')
    ax.set_ylabel('Rank')
    ax.set_title('Top-Ranked Competitors')
    st.line_chart(top_ranked_df['Rank'])
    st.pyplot(fig)
except KeyError as e:
    st.error(f"KeyError: {e}")
    st.write("Available columns in DataFrame:", top_ranked_df.columns)

mycursor.execute("""
    SELECT Competitors.name, Competitors.country, Competitor_Rankings1.ranks, Competitor_Rankings1.points
    FROM Competitors
    INNER JOIN Competitor_Rankings1 ON Competitors.competitor_id = Competitor_Rankings1.competitor_id
    ORDER BY Competitor_Rankings1.points DESC
    LIMIT 10
""")

highest_points_competitors = mycursor.fetchall()
highest_points_df = pd.DataFrame(highest_points_competitors, columns=["Name", "Country", "Rank", "Points"])
st.subheader("Competitors with Highest Points")
st.dataframe(highest_points_df, hide_index=True)

fig, ax = plt.subplots()
try:
    ax.plot(highest_points_df['Name'], highest_points_df['Country'], highest_points_df['Rank'], highest_points_df['Points'])
    ax.set_xlabel('Name')
    ax.set_ylabel('Rank')
    ax.set_title('Competitors with Highest Points')
    st.line_chart(highest_points_df['Rank'])
    st.pyplot(fig)
except KeyError as e:
    st.error(f"KeyError: {e}")
    st.write("Available columns in DataFrame:", highest_points_df.columns)

st.subheader("Analysis of the Tennis Competition Rankings:")
st.write("""The tennis competition features 1,000 competitors from 79 countries, showcasing global participation. Pavic Mate 
         leads with an impressive 9,530 points, reflecting his dominance in the sport. 
         The USA stands out as the top-performing country,
          accumulating 88,009 points, demonstrating its strength in tennis.""")

st.header("COMPLEXES AND VENUE'S")
st.sidebar.header("COMPLEX AND VENUE")

mycursor.execute("""SELECT Complexes.complex_id,Complexes.complex_name,Venues.venue_name,Venues.city_name,
                     Venues.country_name,Venues.country_code,Venues.timezone FROM Venues 
                 inner join Complexes ON Venues.complex_id=Complexes.complex_id""")

data_1 = mycursor.fetchall()
columns_5=['complex_id','complex_name','venue_name','city_name','country_name','country_code','timezone']
df_1 = pd.DataFrame(data_1,columns=columns_5)

fig, ax = plt.subplots()
try:
    ax.plot(df_1['complex_id'], df_1['complex_name'], df_1['venue_name'], df_1['city_name'],df_1['country_name'],df_1['country_code'],df_1['timezone'])
    ax.set_xlabel('complex_id')
    ax.set_ylabel('venue_name')
    ax.set_title('COMPLEXES AND VENUE')
    st.line_chart(df_1['venue_name'])
    st.pyplot(fig)
except KeyError as e:
    st.error(f"KeyError: {e}")
    st.write("Available columns in DataFrame:", df_1.columns)


TOTAL_COMPLEX = df_1["complex_name"].nunique()
st.sidebar.metric(label="TOTAL COMPLEX",value=TOTAL_COMPLEX)

mycursor.execute(""" sELECT 
                             c.complex_name, 
                             COUNT(v.venue_name) AS venue_count
                             FROM Venues v
                             JOIN 
                             Complexes c 
                             ON 
                             v.complex_id = c.complex_id
                             GROUP BY 
                             c.complex_name order by venue_count DESC;
                        """)

data_2 = mycursor.fetchall()
columns_6=['complex_name','venue_count']
df_2 = pd.DataFrame(data_2,columns=columns_6)
st.dataframe(df_2,hide_index=True)

TOTAL_VENUE = df_1["venue_name"].nunique()
st.sidebar.metric(label="TOTAL VENUE",value=TOTAL_VENUE)

fig, ax = plt.subplots()
try:
    ax.plot(df_2['complex_name'], df_2['venue_count'])
    ax.set_xlabel('complex_name')
    ax.set_ylabel('venue_count')
    ax.set_title('Venue Names')
    st.line_chart(df_2['venue_count'])
    st.pyplot(fig)
except KeyError as e:
    st.error(f"KeyError: {e}")
    st.write("Available columns in DataFrame:", df_2.columns)

st.subheader("COMPLEXES AND VENUE'S ANALYSIS")
st.write("""
The tennis complexes host a diverse range of venues, with a total of unique complexes and venues. The app highlights the distribution of venues across complexes, helping to understand the scale and reach of each facility.""")

mycursor.execute("""SELECT Categories.category_id,Categories.category_name,Competitions.competition_name,Competitions.gender,Competitions.parent_id,
                        Competitions.type FROM Competitions
                  INNER JOIN Categories ON Categories.category_id = Competitions.category_id;""")

out=mycursor.fetchall()
columns_7=['category_id','category_name','competition_name','gender','parent_id','type']   
table1_data = pd.DataFrame(out,columns=columns_7)
st.header("COMPETITION'S & CATEGORY TABLE")
st.sidebar.header("COMPETITION'S & CATEGORY")
st.dataframe(table1_data)

fig, ax = plt.subplots()
try:
    ax.plot(table1_data['category_id'], table1_data['category_name'],table1_data['competition_name'],table1_data['gender'],table1_data['parent_id'],table1_data['type'])
    ax.set_xlabel('category_id')
    ax.set_ylabel('gender')
    ax.set_title('COMPETITIONS & CATEGORY TABLE')
    st.line_chart(table1_data['category_name'])
    st.pyplot(fig)
except KeyError as e:
    st.error(f"KeyError: {e}")
    st.write("Available columns in DataFrame:", table1_data.columns)

count_competitions = len(table1_data["category_name"].unique())
st.sidebar.metric(label="TOTAL_COMPETITIONS",value=count_competitions)


st.sidebar.header("Filter by Gender")
gender = st.sidebar.selectbox("Select Gender:",table1_data ["gender"].unique())


st.subheader("FILTER TABLE BY GENDER")
# Filter data based on gender selection
if gender:
    gen_name= table1_data[table1_data['gender']==gender]
    progress = st.progress(0)
    for i in range(100):
        time.sleep(0.1)
        progress.progress(i+1)
    st.balloons()
    st.write("Gender")
st.dataframe(gen_name,hide_index=True)



st.subheader("COMPETITION ANALYSIS")

st.write("""Out of 5,796 total competitions analyzed,
          male participation 
         is significantly higher compared to 
         female and mixed categories, highlighting a gender
           disparity in competition representation.""")



